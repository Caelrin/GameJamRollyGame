using UnityEngine;
using System.Collections;

public class ScoreValue : MonoBehaviour
{
    public int score_value;
    public bool score_calc = false;


}
