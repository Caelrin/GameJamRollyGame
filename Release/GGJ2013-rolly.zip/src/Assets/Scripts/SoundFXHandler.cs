using UnityEngine;
using System.Collections;

public class SoundFXHandler : MonoBehaviour
{

    public AudioClip hit;
    public AudioClip clear;
    public AudioClip nextLVL;

}
